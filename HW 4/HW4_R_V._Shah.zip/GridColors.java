// Romil Vimalbhai Shah
// 20008692
// CS 570 B
// Homework 4 Due on 27th March 2022

package Recursion_HW4;

import java.awt.Color;

/**
 *  An interface for colors
 *@author Koffman and Wolfgang
 */

public interface GridColors 
{
    Color PATH = Color.green;
    
    Color BACKGROUND = Color.white;
    
    Color NON_BACKGROUND = Color.red;
    
    Color ABNORMAL = NON_BACKGROUND;
    
    Color TEMPORARY = Color.black;
}
/*</exercise>*/